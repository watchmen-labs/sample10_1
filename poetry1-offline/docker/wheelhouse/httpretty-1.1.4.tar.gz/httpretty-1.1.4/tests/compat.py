try:
    from unittest.mock import Mock, patch, call, MagicMock
except ImportError:
    from mock import Mock, patch, call, MagicMock
