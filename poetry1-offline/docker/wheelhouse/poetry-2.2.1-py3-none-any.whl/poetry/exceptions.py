from __future__ import annotations


class PoetryError(Exception):
    pass
